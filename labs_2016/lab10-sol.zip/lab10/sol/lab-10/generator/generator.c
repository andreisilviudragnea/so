/* 
 * Generate a file of given size and fill it with random chars
 * The output is written to stdout
 * 
 * @param: file size
 */


#include "utils.h"
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int main(int argc, char **argv)
{
	DWORD noBytes, i;
	DWORD dwRet, dwBytesWritten;
	char *buffer;
	if (argc != 2) {
		fprintf(stdout, "Usage: ./%s no_bytes > output_file\n", argv[0]);
		return -1;
	}

	sscanf_s(argv[1], "%i", &noBytes, sizeof(int));
	buffer = calloc(noBytes + 1, sizeof(char));
	DIE(buffer == NULL, "calloc");

	srand((int)time(NULL) + noBytes);
	for (i = 0; i < noBytes; i++)
		buffer[i] = rand() % 256;

	dwRet = WriteFile(GetStdHandle(STD_OUTPUT_HANDLE),
						buffer, noBytes, &dwBytesWritten, NULL);
	DIE(dwRet == FALSE, "WriteFile");

	return 0;
}
