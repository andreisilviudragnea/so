/**
 * SO, 2016 - Lab #1, Introduction
 * Task #2, Windows
 *
 * Multiple source files compiling
 */
#include <stdio.h>
#include <stdlib.h>
#include "add.h"

/**
 * add - adds to integers
 * @a: first integer
 * @b: second integer
 *
 * RETURNS: sum @a + @b
 */
int add(int a, int b)
{
	return a + b;
}
