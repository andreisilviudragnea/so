/**
 * SO, 2016 - Lab #1, Introduction
 * Task #1, Windows
 *
 * Welcome to SO, simple greeting program.
 */

#include <stdio.h>

int main(void)
{
	printf("SO, ... Hello World!\n");

	return 0;
}


