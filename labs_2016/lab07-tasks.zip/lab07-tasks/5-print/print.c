#include <stdio.h>

int main(void)
{
	fprintf(stdout, "A");
	fprintf(stderr, "B");

	return 0;
}
