/**
 * SO, 2016
 * Lab #2, Operatii I/O simple
 *
 * Task #3, Linux
 *
 * Full length read/write
 */

#ifndef XFILE_UTIL_H
#define XFILE_UTIL_H

#include <unistd.h>

/* read exactly count bytes or die trying */
ssize_t xread(int fd, void *buf, size_t count);

/* write exactly count bytes or die trying */
ssize_t xwrite(int fd, const void *buf, size_t count);

#endif
