/**
 * SO, 2016
 * Lab #8
 *
 * Task #4, lin
 *
 * Serial implementation of  'fgrep -c'
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

#include "utils.h"

#define MIN(a, b)	((a) < (b) ? (a) : (b))
#define CHUNKS	4


int main(int argc, char **argv)
{
	if (argc != 3) {
		printf("Usage: %s string file\n", argv[0]);
		exit(1);
	}

	int i, c, rc, fd, len, chunks, slen, chunk_size;
	int total = 0;
	char *mem;
	struct stat statbuf;


	char *string = argv[1];

	fd = open(argv[2], O_RDONLY);
	DIE(fd == -1, "open");

	rc = fstat(fd, &statbuf);
	DIE(rc == -1, "fstat");

	len = statbuf.st_size;

	mem = mmap(0, len, PROT_READ | PROT_WRITE, MAP_PRIVATE, fd, 0);
	DIE(mem == MAP_FAILED, "mmap");


	chunk_size = (len + CHUNKS - 1) / CHUNKS;
	slen = strlen(string);

	for (c = 0; c < CHUNKS; c++) {
		chunk_size = MIN(chunk_size, len - c * chunk_size);
		for (i = 0; i < chunk_size - slen + 1; i++) {
			if (memcmp(mem + c * chunk_size + i,
						string, slen) == 0){
				total += 1;
			}
		}
	}

	printf("total = %d\n", total);

	return 0;
}
